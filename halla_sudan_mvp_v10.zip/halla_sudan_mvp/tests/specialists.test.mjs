import { test } from 'node:test';
import assert from 'node:assert/strict';
import { moveRequest, maskContact, matchSpecialists, verificationLabel } from '../src/lib/specialists.mjs';

const user = { id: 'staff1', role: 'admin' };

test('حالات الطلب تتبع المسار المسموح فقط', () => {
  let r = { id: 'r1', status: 'pending', category: 'تقنية وحاسوب' };
  r = moveRequest(r, 'reviewing', user);
  r = moveRequest(r, 'matched', user);
  assert.throws(() => moveRequest(r, 'pending', user), /invalid_transition/);
  r = moveRequest(r, 'completed', user);
  assert.equal(r.history.length, 3);
});

test('المختص غير الموثّق يظهر بعلامة صريحة', () => {
  assert.equal(verificationLabel({ verified: false }), 'لم يتم التحقق منه بعد');
  assert.equal(verificationLabel({}), 'لم يتم التحقق منه بعد');
});

test('الموثّقون يظهرون أولاً ولا يتم اختراع مختصين', () => {
  const list = matchSpecialists(
    { category: 'تقنية وحاسوب' },
    [
      { id: 'a', name: 'أ', categories: ['تقنية وحاسوب'], verified: false },
      { id: 'b', name: 'ب', categories: ['تقنية وحاسوب'], verified: true },
      { id: 'c', name: 'ج', categories: ['تصميم'], verified: true },
      { id: 'd', name: 'د', categories: ['تقنية وحاسوب'], verified: true, available: false },
    ],
  );
  assert.deepEqual(list.map((x) => x.id), ['b', 'a']);
});

test('إخفاء بيانات التواصل في الواجهات العامة', () => {
  assert.equal(maskContact('tahaeisa1212@gmail.com'), 'ta***@gmail.com');
  assert.equal(maskContact('+249960880744'), '+249•••44');
  assert.equal(maskContact(''), '');
});
