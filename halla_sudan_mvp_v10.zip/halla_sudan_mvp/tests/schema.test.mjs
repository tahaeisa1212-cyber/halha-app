import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const sql = readFileSync(new URL('../db/schema.sql', import.meta.url), 'utf8');
const tables = [...sql.matchAll(/create table if not exists (\w+)/g)].map((m) => m[1]);

test('كل جدول مفعّل له RLS', () => {
  for (const t of tables) {
    assert.ok(sql.includes(`alter table ${t} enable row level security`), `RLS missing on ${t}`);
  }
});

test('جدول سجل التدقيق لا يملك سياسة كتابة للعامة', () => {
  const auditPolicies = [...sql.matchAll(/create policy "[^"]+" on audit_log for (\w+)/g)].map((m) => m[1]);
  assert.deepEqual(auditPolicies, ['select']);
});

test('لا يحتوي المخطط على مفاتيح أو أسرار', () => {
  assert.doesNotMatch(sql, /service_role_key|eyJhbGci|sk-[A-Za-z0-9]{10,}/);
});
