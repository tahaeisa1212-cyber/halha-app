import { test } from 'node:test';
import assert from 'node:assert/strict';
import { weightedScore, reviewFlags, canPromote, RUBRIC } from '../src/lib/evaluation.mjs';

test('أوزان المعايير تساوي 1', () => {
  const sum = Object.values(RUBRIC).reduce((a, b) => a + b, 0);
  assert.ok(Math.abs(sum - 1) < 1e-9);
});

test('الدرجة المرجّحة من 5 ومساوية للمتوقع', () => {
  const s = { relevance: 5, accuracy: 5, clarity: 5, cultural: 5, safety: 5 };
  assert.equal(weightedScore(s), 5);
  assert.equal(weightedScore({ relevance: 4, accuracy: 4, clarity: 4, cultural: 4, safety: 4 }), 4);
});

test('يرفض درجات خارج النطاق', () => {
  assert.throws(() => weightedScore({ relevance: 6, accuracy: 5, clarity: 5, cultural: 5, safety: 5 }), /bad_score:relevance/);
});

test('يعلّم الإجابات غير الآمنة للمراجعة', () => {
  assert.deepEqual(reviewFlags({ relevance: 4, accuracy: 4, safety: 2 }), ['safety']);
});

test('المقيّم الآلي لا يستطيع اعتماد نسخته (لا ترقية بدون مراجعة بشرية)', () => {
  const r = canPromote({ humanReviewed: false, evaluatorId: 'ai', humanReviewerId: null, deltaMean: 1, safetyRegressions: 0 });
  assert.equal(r.ok, false);
  assert.equal(r.reason, 'human_review_required');
});

test('يمنع أن يكون المراجع هو نفس المقيّم', () => {
  const r = canPromote({ humanReviewed: true, evaluatorId: 'u1', humanReviewerId: 'u1', deltaMean: 1, safetyRegressions: 0 });
  assert.equal(r.reason, 'evaluator_cannot_self_approve');
});

test('يمنع الترقية عند تراجع في السلامة أو تحسن ضعيف', () => {
  assert.equal(canPromote({ humanReviewed: true, evaluatorId: 'ai', humanReviewerId: 'admin1', deltaMean: 1, safetyRegressions: 1 }).reason, 'safety_regression');
  assert.equal(canPromote({ humanReviewed: true, evaluatorId: 'ai', humanReviewerId: 'admin1', deltaMean: 0.05, safetyRegressions: 0 }).reason, 'insufficient_improvement');
});

test('يسمح بالترقية عند مراجعة بشرية مستقلة وتحسن واضح دون تراجع', () => {
  assert.deepEqual(canPromote({ humanReviewed: true, evaluatorId: 'ai', humanReviewerId: 'admin1', deltaMean: 0.2, safetyRegressions: 0 }), { ok: true });
});
