import { test } from 'node:test';
import assert from 'node:assert/strict';
import { validateFeedback, redactPII } from '../src/lib/feedback.mjs';

test('يقبل تقييماً صحيحاً ويعلّمه كرأي مستخدم غير متحقق', () => {
  const r = validateFeedback({ answerId: 'ans_12345678', rating: 'helpful' });
  assert.equal(r.ok, true);
  assert.equal(r.record.source, 'user_opinion');
  assert.equal(r.record.verified, false);
});

test('يرفض التقييم المجهول أو الحقول الإضافية', () => {
  assert.equal(validateFeedback({ answerId: 'ans_12345678', rating: 'great' }).ok, false);
  const extra = validateFeedback({ answerId: 'ans_12345678', rating: 'helpful', userId: 'x' });
  assert.equal(extra.ok, false);
  assert.match(extra.errors[0], /unknown_fields/);
});

test('يحذف البريد ورقم الهاتف من التعليق قبل التخزين', () => {
  const r = validateFeedback({
    answerId: 'ans_12345678',
    rating: 'not_helpful',
    comment: 'راسلني على test@example.com أو +249 960 880 744',
  });
  assert.equal(r.ok, true);
  assert.ok(!r.record.comment_redacted.includes('example.com'));
  assert.ok(!r.record.comment_redacted.includes('960'));
});

test('يرفض تعليقاً أطول من 500 حرف', () => {
  const r = validateFeedback({ answerId: 'ans_12345678', rating: 'helpful', comment: 'س'.repeat(501) });
  assert.deepEqual(r.errors, ['comment']);
});

test('redactPII لا يغيّر النص العادي', () => {
  assert.equal(redactPII('المتجر ما بيشتغل'), 'المتجر ما بيشتغل');
});
