import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createPromptRegistry } from '../src/lib/prompts.mjs';

const admin = { id: 'admin1', role: 'admin' };
const dev = { id: 'dev1', role: 'editor' };
const body = 'أنت مساعد حلّها. اسأل سؤالاً توضيحياً عند الغموض ولا تدّعي اليقين.';
const body2 = 'أنت مساعد حلّها v2. قدّم خطوات مرقمة واذكر حدود اليقين بوضوح.';

test('لا يمكن لغير المشرف الموافقة أو التفعيل', () => {
  const reg = createPromptRegistry();
  const id = reg.propose({ name: 'base', body, actor: dev });
  assert.throws(() => reg.approve(id, dev), /forbidden/);
  reg.approve(id, admin);
  assert.throws(() => reg.activate(id, dev), /forbidden/);
});

test('لا يمكن للمقترِح أن يوافق على نسخته', () => {
  const reg = createPromptRegistry();
  const id = reg.propose({ name: 'base', body, actor: admin });
  assert.throws(() => reg.approve(id, admin), /self_approval_forbidden/);
});

test('لا يمكن تفعيل نسخة غير موافق عليها', () => {
  const reg = createPromptRegistry();
  const id = reg.propose({ name: 'base', body, actor: dev });
  assert.throws(() => reg.activate(id, admin), /not_approved/);
});

test('التراجع يعيد النسخة المستقرة السابقة ويسجّل ذلك في السجل', () => {
  const reg = createPromptRegistry();
  const a = reg.propose({ name: 'v1', body, actor: dev });
  reg.approve(a, admin);
  reg.activate(a, admin);
  const b = reg.propose({ name: 'v2', body: body2, actor: dev });
  reg.approve(b, admin);
  reg.activate(b, admin);
  assert.equal(reg.activeId, b);

  const restored = reg.rollback(admin);
  assert.equal(restored, a);
  assert.equal(reg.activeId, a);
  assert.equal(reg.get(b).status, 'rolled_back');
  assert.ok(reg.audit.some((e) => e.action === 'prompt.rolled_back'));
});

test('لا يوجد تراجع بدون نسخة سابقة', () => {
  const reg = createPromptRegistry();
  const a = reg.propose({ name: 'v1', body, actor: dev });
  reg.approve(a, admin);
  reg.activate(a, admin);
  assert.throws(() => reg.rollback(admin), /no_previous_stable/);
});

test('التراجع من غير المشرف مرفوض', () => {
  const reg = createPromptRegistry();
  assert.throws(() => reg.rollback(dev), /forbidden/);
});
