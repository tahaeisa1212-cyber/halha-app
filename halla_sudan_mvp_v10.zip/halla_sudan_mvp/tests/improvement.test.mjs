import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createProposal, transition, compareRuns } from '../src/lib/improvement.mjs';

const admin = { id: 'admin1', role: 'admin' };
const admin2 = { id: 'admin2', role: 'admin' };
const dev = { id: 'dev1', role: 'editor' };
const aiAgent = { id: 'ai-optimizer', role: 'ai' };

test('لا ينتقل الاقتراح إلى "tested" بدون تقييم ناجح', () => {
  const p = createProposal({ title: 'x', kind: 'prompt', proposedBy: dev });
  assert.throws(() => transition(p, 'tested', dev), /evaluation_required/);
});

test('الذكاء الاصطناعي لا يستطيع الموافقة أو النشر', () => {
  let p = createProposal({ title: 'x', kind: 'prompt', proposedBy: dev });
  p = { ...p, state: 'pending_approval', evaluation: { ok: true } };
  assert.throws(() => transition(p, 'approved', aiAgent), /ai_cannot_decide/);
});

test('المسار الكامل: اختبار -> موافقة مشرف مختلف -> نشر -> تراجع', () => {
  let p = createProposal({ title: 'x', kind: 'prompt', proposedBy: dev });
  p = { ...p, evaluation: { ok: true } };
  p = transition(p, 'tested', dev);
  p = transition(p, 'pending_approval', dev);
  p = transition(p, 'approved', admin);
  assert.equal(p.approvedBy, 'admin1');
  p = transition(p, 'deployed', admin2);
  p = transition(p, 'rolled_back', admin2);
  assert.equal(p.state, 'rolled_back');
  assert.equal(p.history.length, 5);
});

test('لا يمكن النشر قبل الموافقة', () => {
  let p = createProposal({ title: 'x', kind: 'prompt', proposedBy: dev });
  p = { ...p, state: 'approved', approvedBy: null };
  assert.throws(() => transition(p, 'deployed', admin), /not_approved/);
});

test('لا يحق للمقترِح أن يوافق على اقتراحه', () => {
  let p = createProposal({ title: 'x', kind: 'prompt', proposedBy: admin });
  p = { ...p, state: 'pending_approval', evaluation: { ok: true } };
  assert.throws(() => transition(p, 'approved', admin), /self_approval_forbidden/);
});

test('compareRuns يكشف التحسن ويحسب تراجعات السلامة', () => {
  const base = [
    { caseId: 'c1', score: 3.0, safetyViolation: false },
    { caseId: 'c2', score: 3.5, safetyViolation: false },
  ];
  const cand = [
    { caseId: 'c1', score: 4.0, safetyViolation: false },
    { caseId: 'c2', score: 4.0, safetyViolation: true },
  ];
  const r = compareRuns(base, cand);
  assert.equal(r.deltaMean, 0.75);
  assert.equal(r.safetyRegressions, 1);
});

test('compareRuns يرفض مجموعات اختبار مختلفة', () => {
  assert.throws(() => compareRuns(
    [{ caseId: 'a', score: 1, safetyViolation: false }],
    [{ caseId: 'b', score: 1, safetyViolation: false }],
  ), /dataset_mismatch/);
});
