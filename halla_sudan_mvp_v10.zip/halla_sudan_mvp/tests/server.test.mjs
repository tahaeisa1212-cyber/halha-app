import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createApp, validateChat } from '../src/server/app.mjs';
import { createRouter, createRateLimiter, openAICompatible } from '../src/server/provider.mjs';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
const noSleep = async () => {};
let server, base, feedbackStore, behavior;

// مزوّد وهمي يتحكم به كل اختبار
const fakeFetch = async (url, init) => {
  if (url.endsWith('/chat/completions')) return behavior(url, init);
  throw new Error('unexpected url ' + url);
};

before(async () => {
  feedbackStore = [];
  const router = createRouter({
    providers: [openAICompatible({ id: 'hosted', baseUrl: 'https://fake.test/v1', apiKey: 'SECRET_KEY_123', model: 'm' })],
    fetchImpl: fakeFetch, sleep: noSleep, maxRetries: 0,
  });
  const limiter = createRateLimiter({ limit: 50, windowMs: 60_000 });
  server = createApp({ router, limiter, systemPrompt: 'SYSTEM', rootDir: ROOT, feedbackStore });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => new Promise((r) => server.close(r)));

const post = (path, body, raw = false) => fetch(base + path, {
  method: 'POST', headers: { 'content-type': 'application/json' },
  body: raw ? body : JSON.stringify(body),
});

test('الصفحة الرئيسية تُخدم مع ترويسات أمان', async () => {
  const r = await fetch(base + '/');
  assert.equal(r.status, 200);
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
  assert.equal(r.headers.get('x-frame-options'), 'DENY');
  assert.match(await r.text(), /<html lang="ar" dir="rtl">/);
});

test('نقطة الصحة لا تكشف أي مفتاح', async () => {
  const r = await fetch(base + '/api/health');
  const text = await r.text();
  assert.equal(r.status, 200);
  assert.ok(!text.includes('SECRET_KEY_123'));
});

test('المحادثة تعيد رد المزوّد النظيف', async () => {
  behavior = async () => ({ ok: true, status: 200, json: async () => ({ choices: [{ message: { content: 'خطوة أولى...' } }] }) });
  const r = await post('/api/chat', { messages: [{ role: 'user', content: 'عندي مشكلة في الموقع' }] });
  assert.equal(r.status, 200);
  const data = await r.json();
  assert.equal(data.text, 'خطوة أولى...');
  assert.equal(data.provider, undefined);
});

test('التعليمات الأساسية تُضاف على الخادم ولا يرسلها المتصفح', async () => {
  let sent;
  behavior = async (url, init) => { sent = JSON.parse(init.body); return { ok: true, status: 200, json: async () => ({ choices: [{ message: { content: 'x' } }] }) }; };
  await post('/api/chat', { messages: [{ role: 'user', content: 'سلام' }] });
  assert.equal(sent.messages[0].role, 'system');
  assert.equal(sent.messages[0].content, 'SYSTEM');
});

test('عطل المزوّد يعيد رسالة عامة بدون تفاصيل داخلية', async () => {
  behavior = async () => ({ ok: false, status: 500, json: async () => ({ error: 'internal provider details' }) });
  const r = await post('/api/chat', { messages: [{ role: 'user', content: 'سلام يا زول' }] });
  assert.equal(r.status, 503);
  const text = await r.text();
  assert.match(text, /ai_unavailable/);
  assert.ok(!text.includes('provider details'));
  assert.ok(!text.includes('SECRET_KEY_123'));
});

test('مدخلات غير صالحة تُرفض بـ 400', async () => {
  assert.equal((await post('/api/chat', 'not json', true)).status, 400);
  assert.equal((await post('/api/chat', { messages: [] })).status, 400);
  assert.equal((await post('/api/chat', { messages: [{ role: 'system', content: 'hack' }] })).status, 400);
  assert.equal((await post('/api/chat', { messages: [{ role: 'assistant', content: 'أنا' }] })).status, 400);
  assert.equal((await post('/api/chat', { messages: [{ role: 'user', content: 'x'.repeat(2001) }] })).status, 400);
});

test('حمولة أكبر من الحد تُرفض بـ 413', async () => {
  const big = JSON.stringify({ messages: [{ role: 'user', content: 'a'.repeat(20000) }] });
  const r = await post('/api/chat', big, true);
  assert.ok([413, 400].includes(r.status));
});

test('التغذية الراجعة تُقبل إذا كانت صحيحة وتُرفض الحقول الزائدة', async () => {
  const ok = await post('/api/feedback', { answerId: 'ans_12345678', rating: 'helpful' });
  assert.equal(ok.status, 201);
  assert.equal(feedbackStore.length, 1);
  assert.equal(feedbackStore[0].verified, false);
  const bad = await post('/api/feedback', { answerId: 'ans_12345678', rating: 'helpful', userId: 'u1' });
  assert.equal(bad.status, 400);
});

test('المسارات غير المعروفة لا تكشف شيئاً', async () => {
  const r = await fetch(base + '/server.mjs');
  assert.equal(r.status, 404);
  assert.equal((await fetch(base + '/api/unknown')).status, 404);
});

test('validateChat يسقط الرسائل غير الصالحة ويقبل الصالحة', () => {
  assert.equal(validateChat({ messages: [{ role: 'user', content: '  مرحبا  ' }] }).messages[0].content, 'مرحبا');
  assert.equal(validateChat({ messages: [{ role: 'user', content: 'hi' }], containsPersonalData: 'yes' }).ok, false);
});
