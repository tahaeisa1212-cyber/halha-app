import { test } from 'node:test';
import assert from 'node:assert/strict';
import { openAICompatible, createRouter, createRateLimiter } from '../src/server/provider.mjs';

const ok = (text) => ({ ok: true, status: 200, json: async () => ({ choices: [{ message: { content: text } }], usage: { total_tokens: 7 } }) });
const fail = (status) => ({ ok: false, status, json: async () => ({}) });
const noSleep = async () => {};
const messages = [{ role: 'user', content: 'مرحبا' }];

function provider(id, fetchImpl, extra = {}) {
  return openAICompatible({ id, baseUrl: 'https://example.test/v1', apiKey: 'KEY', model: 'm', ...extra });
}

test('نجاح: يعيد النص ويرسل المفتاح في الترويسة فقط', async () => {
  let seen;
  const f = async (url, init) => { seen = { url, init }; return ok('الرد'); };
  const r = createRouter({ providers: [provider('a', f)], fetchImpl: f, sleep: noSleep });
  const out = await r.complete({ messages });
  assert.equal(out.text, 'الرد');
  assert.equal(out.provider, 'a');
  assert.equal(seen.url, 'https://example.test/v1/chat/completions');
  assert.equal(seen.init.headers.authorization, 'Bearer KEY');
  assert.equal(JSON.parse(seen.init.body).model, 'm');
});

test('المفتاح لا يظهر في نتيجة الاستجابة', async () => {
  const f = async () => ok('نص');
  const r = createRouter({ providers: [provider('a', f)], fetchImpl: f, sleep: noSleep });
  const out = JSON.stringify(await r.complete({ messages }));
  assert.ok(!out.includes('KEY'));
});

test('429 يُعاد المحاولة ثم ينجح', async () => {
  let calls = 0;
  const f = async () => (++calls === 1 ? fail(429) : ok('تم'));
  const r = createRouter({ providers: [provider('a', f)], fetchImpl: f, sleep: noSleep });
  assert.equal((await r.complete({ messages })).text, 'تم');
  assert.equal(calls, 2);
});

test('400 لا يُعاد المحاولة (خطأ دائم)', async () => {
  let calls = 0;
  const f = async () => { calls++; return fail(400); };
  const r = createRouter({ providers: [provider('a', f)], fetchImpl: f, sleep: noSleep });
  await assert.rejects(r.complete({ messages }), (e) => e.code === 'upstream_error' && e.retryable === false);
  assert.equal(calls, 1);
});

test('500 متكرر يتوقف بعد عدد المحاولات المحدد', async () => {
  let calls = 0;
  const f = async () => { calls++; return fail(500); };
  const r = createRouter({ providers: [provider('a', f)], fetchImpl: f, sleep: noSleep, maxRetries: 2 });
  await assert.rejects(r.complete({ messages }), (e) => e.code === 'upstream_error');
  assert.equal(calls, 3);
});

test('المهلة الزمنية تُحوَّل إلى خطأ timeout', async () => {
  const f = (url, init) => new Promise((_, reject) => {
    init.signal.addEventListener('abort', () => { const e = new Error('aborted'); e.name = 'AbortError'; reject(e); });
  });
  const r = createRouter({ providers: [provider('a', f)], fetchImpl: f, sleep: noSleep, timeoutMs: 20, maxRetries: 0 });
  await assert.rejects(r.complete({ messages }), (e) => e.code === 'timeout');
});

test('رد فارغ أو غير JSON يُعامل كخطأ bad_response', async () => {
  const f = async () => ({ ok: true, status: 200, json: async () => ({ choices: [{ message: { content: '  ' } }] }) });
  const r = createRouter({ providers: [provider('a', f)], fetchImpl: f, sleep: noSleep, maxRetries: 0 });
  await assert.rejects(r.complete({ messages }), (e) => e.code === 'bad_response');
});

test('بيانات شخصية: لا تُرسل إلى مزوّد احتياطي أبداً', async () => {
  const pa = openAICompatible({ id: 'a', baseUrl: 'https://a.test/v1', model: 'm' });
  const pb = openAICompatible({ id: 'b', baseUrl: 'https://b.test/v1', model: 'm' });
  const hits = { a: 0, b: 0 };
  const f = async (url) => {
    if (url.startsWith('https://a.')) { hits.a++; return fail(503); }
    hits.b++; return ok('احتياطي');
  };
  const r = createRouter({ providers: [pa, pb], fetchImpl: f, sleep: noSleep, maxRetries: 0 });
  await assert.rejects(r.complete({ messages }, { containsPersonalData: true }));
  assert.equal(hits.a, 1);
  assert.equal(hits.b, 0);
});

test('رسالة عامة (بدون بيانات شخصية): يُستخدم الاحتياطي عند فشل الأساسي', async () => {
  const pa = openAICompatible({ id: 'a', baseUrl: 'https://a.test/v1', model: 'm' });
  const pb = openAICompatible({ id: 'b', baseUrl: 'https://b.test/v1', model: 'm' });
  const f = async (url) => (url.startsWith('https://a.') ? fail(500) : ok('احتياطي'));
  const r = createRouter({ providers: [pa, pb], fetchImpl: f, sleep: noSleep, maxRetries: 0 });
  const out = await r.complete({ messages }, { containsPersonalData: false });
  assert.equal(out.provider, 'b');
});

test('بدون مزوّد مُعدّ: يرجع خطأ unconfigured', async () => {
  const r = createRouter({ providers: [], sleep: noSleep });
  await assert.rejects(r.complete({ messages }), (e) => e.code === 'unconfigured');
});

test('إعداد ناقص يفشل مبكراً', () => {
  assert.throws(() => openAICompatible({ id: 'x', baseUrl: '', model: 'm' }), /provider_misconfigured/);
});

test('إحصاءات: تسجّل النجاح والفشل وزمن الاستجابة', async () => {
  let t = 0;
  const f = async () => ok('ok');
  const r = createRouter({ providers: [provider('a', f)], fetchImpl: f, sleep: noSleep, now: () => (t += 5) });
  await r.complete({ messages });
  const s = r.stats();
  assert.equal(s.ok, 1);
  assert.equal(s.byProvider.a.ok, 1);
  assert.ok(s.totalLatencyMs >= 0);
});

test('حد الطلبات: يسمح بالعدد المحدد ثم يرفض', () => {
  let now = 0;
  const rl = createRateLimiter({ limit: 2, windowMs: 1000, now: () => now });
  assert.equal(rl.check('ip').ok, true);
  assert.equal(rl.check('ip').ok, true);
  const third = rl.check('ip');
  assert.equal(third.ok, false);
  assert.ok(third.retryAfter >= 1);
  now = 1001;
  assert.equal(rl.check('ip').ok, true);
});
