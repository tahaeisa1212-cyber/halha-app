-- حلّها: مخطط قاعدة البيانات (PostgreSQL / Supabase)
-- ملاحظة: الكتابة على الجداول الحساسة تتم من الخادم باستخدام مفتاح الخدمة فقط (لا يُكشف للمتصفح).

create extension if not exists pgcrypto;

-- المشرفون (تُدار يدوياً من الخادم فقط)
create table if not exists app_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('admin', 'reviewer')),
  created_at timestamptz not null default now()
);

-- تقييمات المستخدمين: رأي وليس حقيقة متحقَّقة
create table if not exists ai_feedback (
  id uuid primary key default gen_random_uuid(),
  answer_id text not null check (answer_id ~ '^[a-zA-Z0-9_-]{8,64}$'),
  rating text not null check (rating in ('helpful', 'not_helpful')),
  comment_redacted text check (char_length(comment_redacted) <= 500),
  prompt_version_id text check (char_length(prompt_version_id) <= 64),
  session_hash text,
  source text not null default 'user_opinion'
    check (source in ('user_opinion', 'verified_outcome', 'auto_evaluation')),
  verified boolean not null default false,
  created_at timestamptz not null default now()
);

-- نسخ التعليمات (prompts) مع الموافقة والتراجع
create table if not exists prompt_versions (
  id text primary key,
  name text not null,
  body text not null check (char_length(body) >= 20),
  parent_id text references prompt_versions(id),
  status text not null check (status in ('proposed', 'approved', 'active', 'retired', 'rolled_back')),
  proposed_by uuid references auth.users(id),
  approved_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  check (approved_by is null or approved_by <> proposed_by)
);

-- اقتراحات التحسين
create table if not exists improvement_proposals (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  kind text not null check (kind in ('prompt', 'knowledge', 'workflow', 'eval_rule')),
  state text not null default 'draft'
    check (state in ('draft', 'tested', 'pending_approval', 'approved', 'deployed', 'rejected', 'rolled_back')),
  proposed_by uuid references auth.users(id),
  approved_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  check (approved_by is null or approved_by <> proposed_by)
);

-- مصادر المعرفة مع حالة التحقق
create table if not exists knowledge_sources (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  source_url text,
  published_at date,
  verification_status text not null default 'unverified'
    check (verification_status in ('unverified', 'verified', 'outdated', 'rejected')),
  submitted_by_user boolean not null default false,
  reviewed_by uuid references auth.users(id),
  updated_at timestamptz not null default now()
);

-- طلبات المختصين
create table if not exists specialist_requests (
  id uuid primary key default gen_random_uuid(),
  category text not null,
  description text not null check (char_length(description) <= 2000),
  status text not null default 'pending'
    check (status in ('pending', 'reviewing', 'matched', 'completed', 'rejected')),
  contact_encrypted text,
  created_at timestamptz not null default now()
);

-- سجل التدقيق: إضافة فقط من الخادم
create table if not exists audit_log (
  id bigint generated always as identity primary key,
  actor_id uuid,
  action text not null,
  target text,
  detail jsonb,
  created_at timestamptz not null default now()
);

-- ===== RLS =====
alter table app_admins enable row level security;
alter table ai_feedback enable row level security;
alter table prompt_versions enable row level security;
alter table improvement_proposals enable row level security;
alter table knowledge_sources enable row level security;
alter table specialist_requests enable row level security;
alter table audit_log enable row level security;

create or replace function is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from app_admins where user_id = auth.uid());
$$;
revoke all on function is_admin() from public;
grant execute on function is_admin() to authenticated;

-- التقييمات: أي زائر يضيف تقييماً فقط، ولا يقرأ شيئاً
create policy "feedback_insert" on ai_feedback for insert to anon, authenticated with check (true);
create policy "feedback_admin_read" on ai_feedback for select to authenticated using (is_admin());

-- طلبات المختصين: الإضافة تبدأ بحالة pending فقط، والقراءة للمشرفين
create policy "specialist_request_insert" on specialist_requests for insert to anon, authenticated
  with check (status = 'pending');
create policy "specialist_request_admin_read" on specialist_requests for select to authenticated using (is_admin());

-- المعرفة: المصادر المتحقَّق منها فقط للعامة
create policy "knowledge_public_verified" on knowledge_sources for select to anon, authenticated
  using (verification_status = 'verified');
create policy "knowledge_admin_all" on knowledge_sources for select to authenticated using (is_admin());

-- الإدارة والنسخ والاقتراحات والسجل: قراءة للمشرفين فقط، ولا سياسات كتابة للعامة
create policy "prompts_admin_read" on prompt_versions for select to authenticated using (is_admin());
create policy "proposals_admin_read" on improvement_proposals for select to authenticated using (is_admin());
create policy "audit_select" on audit_log for select to authenticated using (is_admin());
create policy "admins_self_read" on app_admins for select to authenticated using (user_id = auth.uid() or is_admin());

-- تقييد الصلاحيات الأساسية
revoke all on all tables in schema public from anon, authenticated;
grant insert on ai_feedback, specialist_requests to anon, authenticated;
grant select on ai_feedback, specialist_requests, knowledge_sources, prompt_versions,
  improvement_proposals, audit_log, app_admins to authenticated;
grant select on knowledge_sources to anon;
