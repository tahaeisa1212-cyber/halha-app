// خادم HTTP بدون اعتماديات خارجية: يخدم الصفحة ويوفّر واجهات API محمية.
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { validateFeedback } from '../lib/feedback.mjs';

const MAX_BODY = 16 * 1024;
const MAX_MESSAGES = 20;
const MAX_CONTENT = 2000;

function secureHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Cache-Control', 'no-store');
}

function sendJson(res, status, body, extraHeaders = {}) {
  const payload = JSON.stringify(body);
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'content-length': Buffer.byteLength(payload), ...extraHeaders });
  res.end(payload);
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(Object.assign(new Error('too_large'), { status: 413 })); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

/** يتحقق من رسائل المحادثة ويُسقط أي حقل غير متوقع. */
export function validateChat(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) return { ok: false, error: 'invalid_body' };
  const { messages, containsPersonalData = true } = body;
  if (!Array.isArray(messages) || messages.length < 1 || messages.length > MAX_MESSAGES) return { ok: false, error: 'invalid_messages' };
  if (typeof containsPersonalData !== 'boolean') return { ok: false, error: 'invalid_privacy_flag' };
  const clean = [];
  for (const m of messages) {
    if (!m || (m.role !== 'user' && m.role !== 'assistant') || typeof m.content !== 'string') return { ok: false, error: 'invalid_message' };
    const content = m.content.trim();
    if (!content || content.length > MAX_CONTENT) return { ok: false, error: 'invalid_message_length' };
    clean.push({ role: m.role, content });
  }
  if (clean[clean.length - 1].role !== 'user') return { ok: false, error: 'last_message_must_be_user' };
  return { ok: true, messages: clean, containsPersonalData };
}

export function createApp({ router, limiter, systemPrompt, rootDir, feedbackStore = [], now = () => new Date() }) {
  let pageCache = null;

  async function serveIndex(res) {
    pageCache ??= await readFile(join(rootDir, 'index.html'), 'utf8');
    secureHeaders(res);
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-cache' });
    res.end(pageCache);
  }

  async function handleChat(req, res) {
    const key = req.socket.remoteAddress || 'unknown';
    const rl = limiter.check(key);
    if (!rl.ok) return sendJson(res, 429, { error: 'rate_limited' }, { 'retry-after': String(rl.retryAfter) });

    let body;
    try { body = JSON.parse(await readBody(req, MAX_BODY)); }
    catch (e) {
      const tooLarge = e.status === 413;
      return sendJson(res, tooLarge ? 413 : 400, { error: tooLarge ? 'too_large' : 'invalid_json' }, { connection: 'close' });
    }

    const v = validateChat(body);
    if (!v.ok) return sendJson(res, 400, { error: v.error });

    try {
      const out = await router.complete(
        { messages: [{ role: 'system', content: systemPrompt }, ...v.messages] },
        { containsPersonalData: v.containsPersonalData },
      );
      // لا يُعاد اسم المزوّد أو تفاصيل الخطأ للمتصفح؛ النص فقط
      return sendJson(res, 200, { text: out.text });
    } catch (e) {
      // رسالة عامة للمستخدم؛ التفاصيل تبقى على الخادم
      console.error('[chat] provider failure:', e.code || e.message);
      return sendJson(res, 503, { error: 'ai_unavailable' });
    }
  }

  async function handleFeedback(req, res) {
    const key = req.socket.remoteAddress || 'unknown';
    if (!limiter.check('fb:' + key).ok) return sendJson(res, 429, { error: 'rate_limited' });
    let body;
    try { body = JSON.parse(await readBody(req, MAX_BODY)); }
    catch (e) { return sendJson(res, e.status === 413 ? 413 : 400, { error: 'invalid_json' }); }
    const v = validateFeedback(body, { now: now() });
    if (!v.ok) return sendJson(res, 400, { error: 'invalid_feedback', fields: v.errors });
    feedbackStore.push(v.record);   // التخزين الدائم يتم عبر جدول ai_feedback في Supabase (انظر db/schema.sql)
    return sendJson(res, 201, { ok: true });
  }

  async function handle(req, res) {
    secureHeaders(res);
    const url = new URL(req.url, 'http://localhost');
    if (req.method === 'GET' && url.pathname === '/api/health') {
      return sendJson(res, 200, { ok: true, providers: router.describe() });
    }
    if (req.method === 'POST' && url.pathname === '/api/chat') return handleChat(req, res);
    if (req.method === 'POST' && url.pathname === '/api/feedback') return handleFeedback(req, res);
    if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html')) return serveIndex(res);
    return sendJson(res, 404, { error: 'not_found' });
  }

  return createServer((req, res) => {
    handle(req, res).catch(() => {
      if (!res.headersSent) sendJson(res, 500, { error: 'internal' });
    });
  });
}
