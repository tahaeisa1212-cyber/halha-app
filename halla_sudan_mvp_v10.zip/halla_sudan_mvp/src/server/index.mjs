// نقطة التشغيل: تقرأ الإعدادات من متغيرات البيئة فقط.
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { openAICompatible, createRouter, createRateLimiter } from './provider.mjs';
import { createApp } from './app.mjs';
import { SYSTEM_PROMPT_AR } from './prompt.mjs';

const env = process.env;
const providers = [];
// المزوّد المحلي يُفضَّل للبيانات الشخصية لأنه لا يغادر الخادم
if (env.LOCAL_AI_BASE_URL && env.LOCAL_AI_MODEL) {
  providers.push(openAICompatible({ id: 'local', baseUrl: env.LOCAL_AI_BASE_URL, model: env.LOCAL_AI_MODEL, local: true }));
}
if (env.AI_BASE_URL && env.AI_MODEL) {
  providers.push(openAICompatible({ id: 'hosted', baseUrl: env.AI_BASE_URL, apiKey: env.AI_API_KEY || '', model: env.AI_MODEL }));
}

const root = dirname(fileURLToPath(import.meta.url));
const router = createRouter({
  providers,
  timeoutMs: Number(env.AI_TIMEOUT_MS) || 15000,
  maxRetries: Number(env.AI_MAX_RETRIES ?? 2),
});
const limiter = createRateLimiter({ limit: Number(env.RATE_LIMIT_PER_MIN) || 20, windowMs: 60_000 });
const app = createApp({ router, limiter, systemPrompt: SYSTEM_PROMPT_AR, rootDir: join(root, '..', '..') });

const port = Number(env.PORT) || 3000;
app.listen(port, () => console.log(`حلّها تعمل على http://localhost:${port} | مزوّدون: ${providers.length}`));
