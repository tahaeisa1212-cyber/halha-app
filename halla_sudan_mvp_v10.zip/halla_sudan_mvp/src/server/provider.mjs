// طبقة مزوّدي الذكاء الاصطناعي. أي خدمة متوافقة مع واجهة OpenAI (سحابية أو محلية) تُستخدم عبر نفس المحوّل.
// المفاتيح تُقرأ من متغيرات البيئة على الخادم فقط، ولا تصل للمتصفح أبداً.

export class ProviderError extends Error {
  constructor(code, message, { status = null, retryable = false } = {}) {
    super(message);
    this.name = 'ProviderError';
    this.code = code;
    this.status = status;
    this.retryable = retryable;
  }
}

/** محوّل لأي واجهة بصيغة chat/completions (مثل OpenAI أو Ollama أو llama.cpp). */
export function openAICompatible({ id, baseUrl, apiKey = '', model, local = false }) {
  if (!id || !baseUrl || !model) throw new Error(`provider_misconfigured:${id || 'unknown'}`);
  const endpoint = baseUrl.replace(/\/+$/, '') + '/chat/completions';
  return {
    id,
    model,
    local,
    async complete({ messages, maxTokens = 500, temperature = 0.3 }, { fetchImpl, signal }) {
      const headers = { 'content-type': 'application/json' };
      if (apiKey) headers.authorization = `Bearer ${apiKey}`;
      let res;
      try {
        res = await fetchImpl(endpoint, {
          method: 'POST',
          headers,
          signal,
          body: JSON.stringify({ model, messages, max_tokens: maxTokens, temperature }),
        });
      } catch (e) {
        if (e.name === 'AbortError') throw e;
        throw new ProviderError('network', 'network_error', { retryable: true });
      }
      if (!res.ok) {
        const rateLimited = res.status === 429;
        throw new ProviderError(rateLimited ? 'rate_limited' : 'upstream_error', `http_${res.status}`, {
          status: res.status,
          retryable: rateLimited || res.status >= 500,
        });
      }
      let data;
      try { data = await res.json(); }
      catch { throw new ProviderError('bad_response', 'invalid_json'); }
      const text = data?.choices?.[0]?.message?.content;
      if (typeof text !== 'string' || !text.trim()) throw new ProviderError('bad_response', 'empty_content');
      return { text: text.trim(), usage: data.usage ?? null };
    },
  };
}

/**
 * موجّه الطلبات: مهلة لكل محاولة، إعادة محاولة مع تأخير متزايد للأخطاء المؤقتة فقط،
 * وتحويل للمزوّد التالي فقط إذا لم تحتوِ الرسالة على بيانات شخصية.
 */
export function createRouter({
  providers,
  fetchImpl = globalThis.fetch,
  timeoutMs = 15000,
  maxRetries = 2,
  backoffMs = 400,
  sleep = (ms) => new Promise((r) => setTimeout(r, ms)),
  now = () => Date.now(),
}) {
  const stats = { requests: 0, ok: 0, failed: 0, totalLatencyMs: 0, byProvider: {} };

  const record = (id, latency, ok, code) => {
    const p = (stats.byProvider[id] ||= { ok: 0, errors: 0, lastError: null });
    stats.totalLatencyMs += latency;
    if (ok) p.ok += 1; else { p.errors += 1; p.lastError = code; }
  };

  async function callOnce(provider, req) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      return await provider.complete(req, { fetchImpl, signal: ctrl.signal });
    } catch (e) {
      if (e.name === 'AbortError') throw new ProviderError('timeout', 'timeout', { retryable: true });
      if (e instanceof ProviderError) throw e;
      throw new ProviderError('unknown', 'unexpected_error', { retryable: false });
    } finally {
      clearTimeout(timer);
    }
  }

  async function attempt(provider, req) {
    let lastErr;
    for (let i = 0; i <= maxRetries; i++) {
      const t0 = now();
      try {
        const out = await callOnce(provider, req);
        record(provider.id, now() - t0, true);
        return out;
      } catch (e) {
        lastErr = e;
        record(provider.id, now() - t0, false, e.code);
        if (!e.retryable || i === maxRetries) break;
        await sleep(backoffMs * 2 ** i);
      }
    }
    throw lastErr;
  }

  async function complete(req, { containsPersonalData = true } = {}) {
    stats.requests += 1;
    if (!providers.length) {
      stats.failed += 1;
      throw new ProviderError('unconfigured', 'no_provider_configured');
    }
    // الخصوصية: الرسائل الشخصية لا تُرسل إلا للمزوّد الأساسي
    const candidates = containsPersonalData ? providers.slice(0, 1) : providers;
    let lastErr;
    for (const provider of candidates) {
      try {
        const out = await attempt(provider, req);
        stats.ok += 1;
        return { ...out, provider: provider.id };
      } catch (e) {
        lastErr = e;
      }
    }
    stats.failed += 1;
    throw lastErr;
  }

  return {
    complete,
    describe: () => providers.map((p) => ({ id: p.id, local: p.local, model: p.model })),
    stats: () => ({ ...stats, byProvider: { ...stats.byProvider } }),
  };
}

/** حد للطلبات لكل مفتاح (مثلاً عنوان IP مُجزّأ) في نافذة زمنية. */
export function createRateLimiter({ limit = 20, windowMs = 60_000, now = () => Date.now(), maxKeys = 10_000 } = {}) {
  const hits = new Map();
  return {
    check(key) {
      const t = now();
      if (hits.size > maxKeys) hits.clear();
      const e = hits.get(key);
      if (!e || t - e.start >= windowMs) {
        hits.set(key, { start: t, count: 1 });
        return { ok: true, remaining: limit - 1, retryAfter: 0 };
      }
      if (e.count >= limit) {
        return { ok: false, remaining: 0, retryAfter: Math.ceil((windowMs - (t - e.start)) / 1000) };
      }
      e.count += 1;
      return { ok: true, remaining: limit - e.count, retryAfter: 0 };
    },
  };
}
