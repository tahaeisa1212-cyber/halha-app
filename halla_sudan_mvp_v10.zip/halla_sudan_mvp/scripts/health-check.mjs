// فاحص صحة المشروع: يكتشف الأخطاء ويكتب تقريراً. لا يعدّل أي ملف.
import { readFileSync, readdirSync, statSync, writeFileSync, mkdirSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { join, relative } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const ROOT = fileURLToPath(new URL('..', import.meta.url));
const findings = [];
const add = (severity, check, file, message) => findings.push({ severity, check, file, message });

function walk(dir, out = []) {
  for (const name of readdirSync(dir)) {
    if (['node_modules', '.git', 'reports'].includes(name)) continue;
    const p = join(dir, name);
    statSync(p).isDirectory() ? walk(p, out) : out.push(p);
  }
  return out;
}

// 1) أخطاء JavaScript داخل index.html
const htmlPath = join(ROOT, 'index.html');
const html = readFileSync(htmlPath, 'utf8');
const inline = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map((m) => m[1]);
inline.forEach((code, i) => {
  try {
    execFileSync(process.execPath, ['--check', '--input-type=module'], { input: code, stdio: ['pipe', 'pipe', 'pipe'] });
  } catch (e) {
    add('error', 'js-syntax', 'index.html', `خطأ في السكربت المضمّن رقم ${i + 1}: ${String(e.stderr).split('\n').find((l) => /Error|SyntaxError/.test(l)) || 'syntax error'}`);
  }
});

// 2) روابط التنقل الداخلية تشير لشاشة موجودة
const views = new Set([...html.matchAll(/data-view="([a-z]+)"/g)].map((m) => m[1]));
const routeRefs = [...html.matchAll(/href="#\/([a-z]+)"/g)].map((m) => m[1]);
for (const r of new Set(routeRefs)) {
  if (!views.has(r)) add('error', 'broken-route', 'index.html', `رابط #/${r} لا يقابله أي شاشة data-view`);
}
// كل الشاشات يجب أن يكون لها رابط للوصول إليها
for (const v of views) {
  if (!routeRefs.includes(v) && !/data-goto/.test(html)) add('warning', 'orphan-view', 'index.html', `الشاشة ${v} بدون رابط تنقل`);
}

// 3) وسوم أساسية للغة والاتجاه
if (!/<html[^>]*lang="ar"/.test(html) || !/<html[^>]*dir="rtl"/.test(html)) {
  add('error', 'rtl', 'index.html', 'وسم <html> يجب أن يحمل lang="ar" و dir="rtl"');
}

// 4) صور/أيقونات بدون وصف نصي (تجاهل الزخرفية aria-hidden)
const imgNoAlt = [...html.matchAll(/<img\b(?![^>]*alt=)[^>]*>/g)].length;
if (imgNoAlt) add('warning', 'a11y', 'index.html', `${imgNoAlt} صورة بدون alt`);

// 5) تسريب أسرار في أي ملف نصي
const secretPatterns = [
  [/sk-[A-Za-z0-9]{20,}/, 'مفتاح API محتمل'],
  [/eyJhbGciOi[A-Za-z0-9_-]{20,}/, 'JWT محتمل (service role?)'],
  [/service_role/i, 'ذكر service_role'],
];
for (const file of walk(ROOT)) {
  // ملفات الاختبار تحتوي أنماطاً للبحث عن الأسرار، فتُستثنى من هذا الفحص
  if (!/\.(html|mjs|js|json|sql|md)$/.test(file) || file.includes('scripts/health-check') || file.includes(`${'/'}tests${'/'}`)) continue;
  const text = readFileSync(file, 'utf8');
  for (const [re, label] of secretPatterns) {
    if (re.test(text)) add('error', 'secret-leak', relative(ROOT, file), label);
  }
}

// 6) وحدات المنطق تُحمَّل بدون أخطاء
const libs = walk(join(ROOT, 'src/lib')).filter((f) => f.endsWith('.mjs'));
for (const lib of libs) {
  try { await import(pathToFileURL(lib).href); }
  catch (e) { add('error', 'module-load', relative(ROOT, lib), e.message); }
}

// 6b) الصور والملفات المحلية المرجعية في index.html يجب أن تكون موجودة
for (const m of html.matchAll(/(?:src|href)="((?!https?:|data:|mailto:|tel:|#)[^"]+)"/g)) {
  const ref = m[1].split('?')[0];
  try { statSync(join(ROOT, ref)); }
  catch { add('error', 'missing-asset', 'index.html', `الملف المرجعي غير موجود: ${ref}`); }
}

// 7) المخطط: كل جدول له RLS
const sql = readFileSync(join(ROOT, 'db/schema.sql'), 'utf8');
for (const m of sql.matchAll(/create table if not exists (\w+)/g)) {
  if (!sql.includes(`alter table ${m[1]} enable row level security`)) {
    add('error', 'rls-missing', 'db/schema.sql', `الجدول ${m[1]} بدون RLS`);
  }
}

const summary = {
  checkedAt: new Date().toISOString(),
  errors: findings.filter((f) => f.severity === 'error').length,
  warnings: findings.filter((f) => f.severity === 'warning').length,
  findings,
};
mkdirSync(join(ROOT, 'reports'), { recursive: true });
writeFileSync(join(ROOT, 'reports/health-report.json'), JSON.stringify(summary, null, 2));
console.log(`فحص الصحة: ${summary.errors} خطأ، ${summary.warnings} تحذير`);
for (const f of findings) console.log(`[${f.severity}] ${f.check} — ${f.file}: ${f.message}`);
process.exitCode = summary.errors ? 1 : 0;
